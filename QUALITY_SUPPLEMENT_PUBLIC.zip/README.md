# FinNews Equity Core Quality Companion

Additive zero-API documentation and researcher review tools for frozen archive64d5.
Open BLIND_REVIEW.html through any local static HTTP server for source-first review.
No Gold is accepted until the user explicitly adopts or enters it.
Read TASK_DEFINITION_AND_REPRODUCTION_CN.md first.
No commercial news, raw equity prices, trained private coefficients or original dataset mutation.
Code/docs follow MIT of the original public code; public factual research review follows the original source-specific rights.
