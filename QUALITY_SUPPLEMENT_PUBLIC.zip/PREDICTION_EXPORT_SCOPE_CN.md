# 发布后数值复现范围澄清（不改变已发布版本）

最终公开ZIP SHA256仍为 `64d5c17eec084e1c387d76b022a1f19b9416761f0575517da99acea798ecd864`，本次未修改ZIP、公开源码或公开数据。

原“210条预测、630项数值最大误差0”的范围是**包含R1/R3在内的最终七个拟合臂**（PRICE、R0、R1、R2、R3、EMPTY、MISMATCH），每臂三期限、每期限十个评价事件。630项比较分别为每行prediction、raw_prediction、squared_error。它不是添加R1/R3之前的旧版本。

公开aggregate另含ZeroReturn和TrainingMean，因此有九组×三期限=27项聚合结果。公开runtime对这两个常量参照只写聚合，不写逐预测文件；原先未序列化的60条基线预测不应假称已经包含在210行中。

本次从同一最终ZIP在新临时目录、标准库隔离子进程中重新执行已有冻结拟合协议，审计钩子拒绝网络及原工程/E盘私有路径。价格仅显式复制使用者有授权的CSV，仍不分发。七臂210行逐项与原冻结私有预测一致；另从公开公式重建ZeroReturn=0和TrainingMean=成熟训练收益均值的60行，并以原冻结PRICE模型intercept独立核对TrainingMean。

最终共核对九组270条预测，回算27项MSE/MAE共54个公开聚合数值，最大差均为0。七拟合臂增加核对target后为840项数值比较，最大差0；额外60条基线预测值核对差0。新增270行文件只保存到private验证目录。

本次是既有协议复现与范围补充，不是新架构/参数/样本搜索；不改变已发表聚合结果，不新增LLM/API调用。外部实际人类复现仍为NOT_RUN。

详见 `FINAL_27_AGGREGATE_270_PREDICTION_VERIFICATION.json`。
