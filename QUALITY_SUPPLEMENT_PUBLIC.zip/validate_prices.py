"""Validate authorized user price CSV; no downloads, model fitting or price repair.

Schema: asset,date,close,close_at. The sidecar is an explicit statement of source
rights and split-only adjustment. Neither a declaration nor this validator can
establish a provider redistribution license or independently prove adjustment.
"""
import argparse,csv,json,math,hashlib
from collections import defaultdict,Counter
from datetime import datetime,timezone
from pathlib import Path

ASSETS=['AAPL','AMD','AMT','AMZN','CAT','CVX','DIS','GS','MSFT','NEE','TSLA','UNH','WMT']
def utc(s):
 d=datetime.fromisoformat(s.replace('Z','+00:00'))
 if d.tzinfo is None:raise ValueError('TIMEZONE_REQUIRED')
 return d.astimezone(timezone.utc)
def validate(prices,calendar,sidecar,required_assets=ASSETS):
 prices,calendar=map(Path,(prices,calendar))
 if isinstance(sidecar,(str,Path)):sidecar=json.loads(Path(sidecar).read_text(encoding='utf8'))
 errors=[];warnings=[];observations=defaultdict(dict);n=0
 with calendar.open(encoding='utf8',newline='') as f:expected={r['date']:utc(r['close_at']) for r in csv.DictReader(f)}
 needed={'asset','date','close','close_at'}
 with prices.open(encoding='utf-8-sig',newline='') as f:
  reader=csv.DictReader(f)
  if not needed<=set(reader.fieldnames or []):return {'status':'FAIL','errors':[{'code':'MISSING_REQUIRED_COLUMNS','required':sorted(needed)}],'rows':0}
  for line,r in enumerate(reader,2):
   n+=1;asset=r['asset'];day=r['date']
   try:
    datetime.strptime(day,'%Y-%m-%d');at=utc(r['close_at']);close=float(r['close'])
    if not math.isfinite(close) or close<=0:raise ValueError('NONFINITE_OR_NONPOSITIVE_CLOSE')
   except (ValueError,TypeError) as exc:
    errors.append({'code':'INVALID_ROW_VALUE','line':line,'field_detail':str(exc)});continue
   if day[:4] not in {'2020','2021','2022','2023'}:
    errors.append({'code':'OUT_OF_SCOPE_OR_SEALED_YEAR','line':line,'date':day});continue
   if day not in expected:errors.append({'code':'NON_SESSION_DATE','line':line,'date':day});continue
   if at!=expected[day]:errors.append({'code':'WRONG_EXCHANGE_CLOSE','line':line,'date':day,'expected_utc':expected[day].isoformat()})
   if day in observations[asset]:errors.append({'code':'DUPLICATE_ASSET_DATE','line':line,'asset':asset,'date':day})
   observations[asset][day]=close
 for asset in required_assets:
  if asset not in observations:errors.append({'code':'MISSING_REQUIRED_ASSET','asset':asset});continue
  d=observations[asset];lo,hi=min(d),max(d)
  missing=[x for x in expected if lo<=x<=hi and x not in d]
  if missing:errors.append({'code':'MISSING_TRADING_SESSIONS','asset':asset,'count':len(missing),'first':missing[0]})
  ordered=sorted(d)
  for a,b in zip(ordered,ordered[1:]):
   ratio=d[b]/d[a]
   if ratio<.55 or ratio>1.8:warnings.append({'code':'POSSIBLE_SPLIT_OR_REAL_EXTREME_MOVE','asset':asset,'date':b,'automatic_repair':False})
 for key,value in [('adjustment','split'),('dividends','excluded'),('license_use_confirmed',True)]:
  if sidecar.get(key)!=value:errors.append({'code':'MISSING_OR_INCOMPATIBLE_SOURCE_DECLARATION','field':key,'expected':value})
 if not sidecar.get('source'):errors.append({'code':'MISSING_SOURCE_PROVIDER'})
 return {'status':'PASS' if not errors else 'FAIL','rows':n,'assets':len(observations),'required_assets':required_assets,
  'date_min':min((d for a in observations.values() for d in a),default=None),
  'date_max':max((d for a in observations.values() for d in a),default=None),'errors':errors,'warnings':warnings,
  'error_counts':dict(Counter(x['code'] for x in errors)),'price_csv_sha256':hashlib.sha256(prices.read_bytes()).hexdigest(),
  'calendar_sha256':hashlib.sha256(calendar.read_bytes()).hexdigest(),'source_declaration':sidecar,
  'split_adjustment_status':'DECLARED_NOT_INDEPENDENTLY_PROVEN_BY_PRICE_CONTINUITY',
  'redistribution_permission':'NOT_ESTABLISHED_BY_THIS_VALIDATOR','price_repair':'NEVER_PERFORMED',
  'sealed_year_data_requested':False,'new_api_calls':0,'model_fits':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('--prices',type=Path,required=True);p.add_argument('--calendar',type=Path,required=True);p.add_argument('--sidecar',type=Path,required=True);p.add_argument('--assets',default=','.join(ASSETS));p.add_argument('--output',type=Path)
 a=p.parse_args();r=validate(a.prices,a.calendar,a.sidecar,a.assets.split(','))
 s=json.dumps(r,ensure_ascii=False,indent=2)
 if a.output:a.output.write_text(s+'\n',encoding='utf8')
 else:print(s)
 raise SystemExit(0 if r['status']=='PASS' else 1)
if __name__=='__main__':main()
