# FinNews Equity Core：任务与复现说明补充

这份补充包叠加于已发布ZIP64d5…，不替换数据、不重打原ZIP、不新增LLM或模型。它把可研究的任务、字段、时钟和审查方式写清。**实际范围固定为156财报事件、1200数字、36真实Agent状态、138项比较**；旧40新闻族360字段是另一任务集。

## 三个彼此独立的研究任务

1. **来源与数值还原**：由SEC链接/原文件hash/XBRL概念、context、单位、期间及XPath，还原已经报告的数字。机械程序可以判断存在、相等、单位与时点，不可据此宣称经济解释准确率。
2. **经济状态理解**：区分实际、计划、指引、经营变化、反证及不确定性。用户可依据原材料批量采纳可核验事实为研究Gold，无需金融专家；主观经济解释未审定始终Human Gold pending。
3. **条件金融预测复现**：在相同覆盖、价格输入、期限、成熟规则和学习器下比较表示。无独立预测增量不妨碍资源使用；解释正确也不自动证明金融增量。

## 字段与数值语义

`events`一行是一份接受于2021—2023的10-K/10-Q，不是每日样本或新闻转载。`event_id`跨evidence/state/alignment联结；`asset`是目标上市公司。

`evidence`一行是同口径比较中的一个数字：`fact_id`、metric、role、concept、value、display_numeric、scale、sign、decimals、unit_measure、period_start/end、duration_days、context_id、element_id及html_element_xpath。`unit_ref`只是文件内部ID；解释单位必须用unit_measure。无element_id的42条使用唯一XPath，并非缺失证据。

`value`已经应用scale和sign。USD与USD/share不能比较；负净利润改善与收入增长是不同事实。季度与年初至今不能混；53周年允许日数差异但保留实际期间。display与原文位置可以还原，不提供公司的叙事原文或商用新闻全文。

`rule_economic_states`是确定性实际数字对照，不冒称LLM；`real_agent_economic_states`含2026年真实模型研究及原始响应。状态中的经济解释为AI生成，source PASS仅说明引用存在/数字匹配，不证明经济因果。

某指标没有进入comparisons，表示本次抽取没有合格同口径对照，不是该指标为0。预测头可能用0数值槽加0缺失指示编码缺失，但API事实值仍必须保持缺失；这是模型内部编码，不是经济断言。relative_change=(current-prior)/abs(prior)，prior为0时不计算；正负净利润变化不等同盈利能力的完整因果解释。

完整可机器读字段字典见FIELD_DICTIONARY.csv、ENUM_AND_MISSINGNESS.json。运行时应保留原字串和null，不能把UNKNOWN或输入处理失败编码为负面/零影响。

## 四个时钟和两个ASOF口径

- `source_available_at`/`information_cutoff`：历史材料被允许用于该事项的截止，SEC接受时刻不是更早的发行人首次披露时刻。
- `actual_reconstruction_time`：2026年生成数字资源的真实时刻；不是历史公开时刻。
- `actual_generated_at`：真实Agent分析生成时刻；不能倒填成2021—2023预测。
- `forecast_origin`/`first_fill_time`/`return_end`：真实交易所收盘、下一交易日收盘和标签成熟终点。

HISTORICAL_RESEARCH允许用当时已披露的材料做现代重建；STRICT_ASOF同时要求内容首次观察及分析真实生成时间不晚于查询。这个公开历史Agent集不满足严格历史实时验证。

## 状态、未知与缺失

|值/状态|含义|禁止转换|
|---|---|---|
|UNKNOWN|现有证据不足以确定|不能当0、负面或错答|
|NOT_SUPPLIED / NOT_PROVIDED|此输入没有提供该信息|不能推断经济事实不存在|
|null + UNAVAILABLE|分析/输入/模型不可用|不能当无经济影响|
|合法训练后的0|模型没有数值修正或收缩为0|不能冒称新闻无任何信息|
|HUMAN_GOLD_PENDING|没有用户审定开放含义|不能计准确率或当成错误|
|FIELD_ISOLATION|某字段来源/内容不合格|不连带抹去独立合法字段|
|RIGHT_CENSORED|合法终点超出资料截止|不读2024—2025补值|
|BYO_LICENSED_PRICE_COMPUTATION_REQUIRED|价格标签须用户合法数据重算|不是标签为0|

## 同覆盖Benchmark的确切复算

1. 下载原FinNews Equity Core ZIP并核对SHA25664d5…；解压到任意目录，先运行 `python -I -S run.py verify`，无需E盘/AutoDL/API Key。
2. 用自己合法价格CSV，四列asset,date,close,close_at。只支持2020—2023，split-adjusted、排除股息；元信息例见PRICE_SOURCE_DECLARATION.example.json。不授权再分发价格。
3. 先运行补充包 `python validate_prices.py --prices your.csv --calendar ../core/data/XNYS_SESSIONS_2020_2023.csv --sidecar source.json --output price_check.json`。缺失交易日、重复/非法日期、非正价格、错误提前收盘、未声明拆股口径均拒绝。价格跳跃只能提示疑似拆股或真实极端行情，不自动改价。
4. 在原资源目录运行 `python -I -S run.py align --prices your.csv` 和 `python -I -S run.py benchmark --prices your.csv`。CSV始终留在自己授权范围内。没有价格时仍可完整检查公司证据/状态，不能声称已重做金融结果。
5. 目标为close[t+h+1]/close[t+1]-1，h=1/5/20；t是SEC接受后首个可用收盘，t+1收盘才成交。所有价格特征<=t；训练/校准标签需分别在2021/2022内成熟；2023终点越界右删失。
6. 九表示均使用匹配的36真实Agent/Qwen事件覆盖；20日训练12/校准12/评价10。Ridge alpha10、训练统计、校准口径固定；Qwen冻结、16维固定投影，不重新下载/训练。

原runtime只导出七个拟合臂的210条预测；ZeroReturn与TrainingMean另有6项聚合、没有逐条写入predictions.jsonl。因此共27项聚合，不要把210行误认为漏跑R1/R3。本次发布后已补充验证270=210+60常量参照全部聚合相同，未改变原ZIP。详见PREDICTION_EXPORT_SCOPE_CN.md。

价格CSV、逐条未来标签和可逆价格模型参数不在公开包。R1使用新数字事实文本向量，不是原商业新闻Embedding。R2只读取LLM还原的比较槽，恰与R0相同，不声称利用全部开放解释。20日R3收缩0且等于ZeroReturn：保留负结果。

## 人工研究Gold怎样操作

打开BLIND_REVIEW.html。第一阶段仅看原数字/SEC定位，填写研究者名称及空白答案；模型答案默认隐藏。可主动批量采纳列明的机械事实为自己的研究Gold；该按钮不会替你审定因果机制、反证充分性或不确定性。

第二阶段可显式展开模型回答并评价支持、越界推断及不确定性。导出JSON/CSV含审查者/真实时间/采纳依据/争议。不是专家评审就如实标研究者审定，无法判断可保持UNKNOWN；不伪造独立专家Gold或完全盲审。

旧NEWS40_REVIEW有40族×9字段，部分材料仍受限。补充包只提供任务/错误分类交叉表和计数，不复制受限原文或模型值，不与本FILING36_REVIEW合成一个准确率。
