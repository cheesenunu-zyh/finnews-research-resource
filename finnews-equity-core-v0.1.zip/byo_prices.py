"""User-licensed split-adjusted SIP price builder, never part of public raw data.

Requires APCA_API_KEY_ID/APCA_API_SECRET_KEY in your environment and an existing
data entitlement. This does not purchase a plan. The output stays local and is
excluded from the release archive. No credential is printed or written.
"""
import argparse,csv,json,os,time,urllib.parse,urllib.request
from pathlib import Path
def fetch(assets,start,end,output,ack=False):
 if not ack:raise PermissionError('Pass --ack-authorized-data only if your provider agreement permits your use')
 if start<'2019-01-01' or end>'2023-12-31':raise ValueError('Only 2019-2023; sealed 2024-2025 never requested')
 key=os.environ.get('APCA_API_KEY_ID');secret=os.environ.get('APCA_API_SECRET_KEY')
 if not key or not secret:raise RuntimeError('Set your own authorized provider environment; no bundled credentials')
 try:
  import exchange_calendars as xc
 except ImportError:raise RuntimeError('Install optional exchange_calendars for real holiday/early close times') from None
 cal=xc.get_calendar('XNYS',start=start,end=end);sched=cal.schedule
 closes={str(i)[:10]:r.get('close',r.get('market_close')).isoformat() for i,r in sched.iterrows()}
 rows=[];page=None;pages=0
 while True:
  args={'symbols':','.join(assets),'timeframe':'1Day','start':start+'T00:00:00Z','end':end+'T23:59:59Z',
   'adjustment':'split','feed':'sip','limit':10000,'sort':'asc'}
  if page:args['page_token']=page
  req=urllib.request.Request('https://data.alpaca.markets/v2/stocks/bars?'+urllib.parse.urlencode(args),
   headers={'APCA-API-KEY-ID':key,'APCA-API-SECRET-KEY':secret})
  # No automatic retry or fallback to a different feed/adjustment.
  with urllib.request.urlopen(req,timeout=120) as r:obj=json.load(r)
  pages+=1
  for asset,bars in obj.get('bars',{}).items():
   for b in bars:
    d=b['t'][:10]
    if d not in closes:raise ValueError('PROVIDER_BAR_NOT_IN_XNYS_CALENDAR')
    rows.append({'asset':asset,'date':d,'close':b['c'],'close_at':closes[d]})
  page=obj.get('next_page_token')
  if not page:break
  time.sleep(.2)
 if len({(r['asset'],r['date']) for r in rows})!=len(rows):raise ValueError('DUPLICATE_PROVIDER_ROWS')
 output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
 with output.open('w',encoding='utf8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['asset','date','close','close_at']);w.writeheader();w.writerows(sorted(rows,key=lambda r:(r['asset'],r['date'])))
 print(json.dumps({'rows':len(rows),'pages':pages,'feed':'sip','adjustment':'split','end':end,
  'output_is_private':'Do not publish without your own provider/exchange redistribution permission'}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--assets',default='AAPL,AMD,AMT,AMZN,CAT,CVX,DIS,GS,MSFT,NEE,TSLA,UNH,WMT');p.add_argument('--start',default='2020-01-01');p.add_argument('--end',default='2023-12-31');p.add_argument('--output',type=Path,required=True);p.add_argument('--ack-authorized-data',action='store_true');a=p.parse_args();fetch(a.assets.split(','),a.start,a.end,a.output,a.ack_authorized_data)
