# FinNews Equity Core 0.1

A real company financial-state research subset: 156 reported financial events,
13 US equities, 2021–2023 acceptance years, 1,200 numeric iXBRL facts, original
filing locators, deterministic state comparisons, and a separately identified
new real-LLM research subset when its response file is present.

This is a new numeric-filing subset. It is **not** the original 580 News Agent
analyses renamed as SEC-aware analysis. All 580 original families receive a
field-level rights decision; their open news-based explanations remain restricted.
Even the old closed-enum lineage stays restricted pending provider contract
verification. The public package carries only its field-rights decisions and
source-classification correction counts, not the old state values.

## Try without an API key, E: drive, AutoDL or scientific Python packages

```sh
python -I -S run.py reproduce
python -I -S run.py query --asset AAPL
python -I -S run.py verify
```

These commands inspect the **real company events and frozen states**, recompute
numeric comparisons and verify identifiers/periods/scale. They do not silently
call an LLM or claim to replicate a private financial benchmark. See data/ for
current/prior actuals, original SEC URLs and iXBRL contexts/element IDs.

## Reproduce stock-price alignment and the low-capacity matched benchmark

Raw SIP prices/labels are not redistributable merely because they were used in
research. Supply an authorized CSV with `asset,date,close,close_at`; close_at is
the true UTC XNYS close, including early closes. Use split-adjusted prices,
excluding dividends. All date/label calculations stop at 2023-12-31.

```sh
# Optional: use your own existing Alpaca SIP entitlement, not a bundled key.
# Requires exchange_calendars solely for holiday/early-close construction.
python byo_prices.py --output private_prices.csv --ack-authorized-data
python -I -S run.py align --prices private_prices.csv
python -I -S run.py benchmark --prices private_prices.csv
```

The price formula is close[t+h+1]/close[t+1]-1, h=1/5/20: first eligible exchange
close after SEC acceptance is t; fill is t+1 close. Missing sessions are rejected.
Inputs use only prices observed by t; unavailable future labels are null/right
censored, never fetched from 2024–2025. Default example evaluation trains2021,
calibrates2022, evaluates2023 on the same mature, valid real-Agent event coverage.
Ridge alpha10, identical heads and train-only standardization. R0 rule, R2 factual
Agent comparisons, PRICE and EMPTY are executable. If R0/R2 vectors are identical
their predictions may be identical: this is reported, not called semantic alpha.
When PUBLIC_QWEN_VECTORS.jsonl is present, R1 uses newly encoded complete numeric
fact rows with the same existing frozen Qwen checkpoint (no download/backbone
training); R3 uses eight projected Qwen slots plus eight Agent fact slots. All
heads have 22 coordinates. MISMATCH uses the most recent strictly earlier
wrong-company state, keeps missing predecessors, and retrains on that mapping.
Original news embeddings cannot be reused after changing text. If the new vector
file is absent R1/R3 are NOT_RUN. The old private580 result is a different
population and is never mixed into this public benchmark. q10 not newly trained.

## What is and is not validated

Numeric facts, units, periods and exact source locators are mechanically checked.
Human economic interpretation review remains HUMAN_GOLD_PENDING. Actual revenue
growth is not demand surprise, guidance revision or a stock-return forecast.
The frozen modern Agent response time is recorded in 2026; these are historical
reconstructions, not contemporaneous 2021–2023 predictions. Strict historical
ASOF Agent access is unavailable. No trading/Coordinator/memory experiment here.

## Rights

Code/docs MIT. Our original annotations and arrangement CC BY 4.0. Non-expressive
financial facts are not claimed as copyright; retain SEC/source attribution.
No issuer narrative, logos, commercial news quotes, news embeddings, private
checkpoints, raw SIP prices or credentials are distributed. See FIELD_RIGHTS.md.
Automated isolated reproduction is not independent external human reproduction.
