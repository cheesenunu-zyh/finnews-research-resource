"""Portable public resource reader and licensed bring-your-own-price benchmark.

Standard library only. No credentials, private directory or LLM is required to
inspect and reproduce states. Price evaluation explicitly requires the user's
own authorized CSV; nothing silently downloads or substitutes market data.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,math,statistics
from collections import defaultdict,Counter
from datetime import datetime,timezone,timedelta
from pathlib import Path

def readl(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
def writej(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def writel(p,x):p.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True,allow_nan=False)+'\n' for r in x),encoding='utf8')
def stamp(s):return datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)
def vector_rule(s):
 x=[]
 for m in ['revenue','net_income','eps_diluted','operating_income']:
  c=s['comparisons'].get(m)
  x.extend([max(-3,min(3,c['relative_change'])) if c and c['relative_change'] is not None else 0,
            float(bool(c))])
 return x+[0.]*8

def vector_agent(s):
 # Closed supported comparisons, not confidence or generated returns. The input
 # may still fail to outperform rules; exact identity is reported rather than hidden.
 obj=s.get('parsed_output') or {};checks=s.get('validation',{});ok={c['metric'] for c in checks.get('comparisons',[]) if c['status']=='PASS'}
 cs={c['metric']:c for c in obj.get('comparisons',[]) if c.get('metric') in ok};x=[]
 for m in ['revenue','net_income','eps_diluted','operating_income']:
  c=cs.get(m);old=c.get('previous_value') if c else None
  g=(c['current_value']-old)/abs(old) if c and old else 0
  x.extend([max(-3,min(3,g)),float(bool(c))])
 # Keep explanations in the resource, but this low-capacity head only consumes
 # fact-comparison slots. It does not claim to exploit the full open reasoning.
 return x+[0.]*8

def audit_agent(row,event,facts):
 """Recheck public frozen outputs against bundled facts; do not trust saved PASS."""
 obj=row.get('parsed_output');errors=[];checks=[]
 if not isinstance(obj,dict):return {'source_legality':'FAIL','comparisons':[],'errors':['NOT_OBJECT']}
 if obj.get('event_id')!=event['event_id'] or obj.get('target_asset')!=event['asset']:
  return {'source_legality':'FAIL','comparisons':[],'errors':['IDENTITY']}
 allowed={f['fact_id']:f for f in facts if f['event_id']==event['event_id']}
 for k in ['support_ids','counter_ids']:
  ids=obj.get(k)
  if not isinstance(ids,list) or any(not isinstance(i,str) or i not in allowed for i in ids):errors.append('ILLEGAL_'+k)
 interpretation=obj.get('operating_interpretation')
 if not isinstance(interpretation,dict) or not isinstance(interpretation.get('evidence_ids'),list) or any(not isinstance(i,str) or i not in allowed for i in interpretation.get('evidence_ids',[])):errors.append('ILLEGAL_INTERPRETATION')
 cc=obj.get('comparisons')
 if not isinstance(cc,list):return {'source_legality':'FAIL','comparisons':[],'errors':['COMPARISONS_SCHEMA']}
 for c in cc:
  reason=[]
  if not isinstance(c,dict):checks.append({'metric':None,'status':'ISOLATED','errors':['NOT_OBJECT']});continue
  ids=c.get('evidence_ids');fs=[allowed[i] for i in ids if i in allowed] if isinstance(ids,list) and all(isinstance(i,str) for i in ids) else []
  now=[f for f in fs if f['role']=='current'];old=[f for f in fs if f['role']=='prior_same_duration']
  if len(fs)!=2 or len(now)!=1 or len(old)!=1:reason.append('UNSUPPORTED_COMPARISON')
  else:
   a,b=now[0],old[0]
   if a['metric']!=b['metric'] or c.get('metric')!=a['metric'] or a['unit_measure']!=b['unit_measure']:reason.append('METRIC_OR_UNIT')
   for k,v in [('current_value',a['value']),('previous_value',b['value'])]:
    n=c.get(k)
    if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) or not math.isclose(n,v,rel_tol=1e-12,abs_tol=1e-8):reason.append('VALUE')
   if c.get('current_period_end')!=a['period_end'] or c.get('previous_period_end')!=b['period_end']:reason.append('PERIOD')
   expected='INCREASE' if a['value']>b['value'] else 'DECREASE' if a['value']<b['value'] else 'UNCHANGED'
   if c.get('direction')!=expected:reason.append('DIRECTION')
  checks.append({'metric':c.get('metric'),'status':'PASS' if not reason else 'ISOLATED','errors':reason})
 return {'source_legality':'PASS' if not errors and all(c['status']=='PASS' for c in checks) else 'FIELD_ISOLATION','comparisons':checks,'errors':errors}

def verify(data):
 events=readl(data/'events.jsonl');facts=readl(data/'evidence.jsonl');rules=readl(data/'rule_economic_states.jsonl')
 em={e['event_id']:e for e in events};fm={f['fact_id']:f for f in facts};errors=[];numeric=0
 for f in facts:
  if f['event_id'] not in em:errors.append('ORPHAN_FACT')
  try:
   n=float(f['display_numeric'].replace(',','').replace('(','').replace(')','').replace('$','').strip())*10**f['scale']
   if f['sign']=='-' or '(' in f['display_numeric']:n=-abs(n)
   if not math.isclose(n,f['value'],rel_tol=1e-12,abs_tol=1e-8):errors.append('DISPLAY_SCALE')
   numeric+=1
  except ValueError:errors.append('NUMERIC_FORMAT')
  if stamp(f['available_at'])>stamp(em[f['event_id']]['information_cutoff']):errors.append('FUTURE_FACT')
 for s in rules:
  for m,c in s['comparisons'].items():
   cur,old=[fm[i] for i in c['evidence_ids']]
   if cur['value']!=c['current_value'] or old['value']!=c['prior_value']:errors.append('RULE_VALUE')
   if cur['metric']!=m or old['metric']!=m:errors.append('METRIC')
   if abs(cur['duration_days']-old['duration_days'])>12:errors.append('INCOMPARABLE_DURATION')
 agents=readl(data/'real_agent_economic_states.jsonl') if (data/'real_agent_economic_states.jsonl').exists() else []
 agent_checks=[audit_agent(a,em[a['event_id']],facts) for a in agents if a['event_id'] in em]
 for a in agent_checks:
  errors.extend(a['errors']);errors.extend(e for c in a['comparisons'] for e in c['errors'])
 receipt={'status':'PASS' if not errors else 'FAIL','events':len(events),'assets':len({e['asset'] for e in events}),
  'numeric_facts_checked':numeric,'rule_states':len(rules),'real_agent_states':len(agents),
  'real_agent_comparisons_rechecked':sum(len(c['comparisons']) for c in agent_checks),'errors':Counter(errors),
  'human_semantic_gold':'PENDING','investment_value':'NOT_RUN','price_data':'BYO_AUTHORIZED_REQUIRED',
  'no_network_or_paid_calls':True,'verification_scope':'NUMERIC_FACTS_AND_REFERENTIAL_CONTRACT_NOT_EXPERT_SEMANTIC_ACCURACY'}
 return receipt

def load_prices(path):
 groups=defaultdict(list)
 with Path(path).open(encoding='utf8',newline='') as f:
  for r in csv.DictReader(f):
   if r['date'][:4] not in {'2019','2020','2021','2022','2023'}:raise ValueError('SEALED_OR_OUT_OF_SCOPE_PRICE_YEAR')
   c=float(r['close']);at=stamp(r['close_at'])
   if not math.isfinite(c) or c<=0:raise ValueError('BAD_PRICE')
   if at.date().isoformat()!=r['date']:raise ValueError('UTC_CLOSE_DATE_MISMATCH')
   groups[r['asset']].append(dict(r,close=c,instant=at))
 for a,rows in groups.items():
  rows.sort(key=lambda r:r['date'])
  if len({r['date'] for r in rows})!=len(rows):raise ValueError('DUPLICATE_PRICE_ROW')
 return groups

def align(data,prices):
 groups=load_prices(prices);out=[]
 calendar=data/'XNYS_SESSIONS_2020_2023.csv'
 if calendar.exists():
  with calendar.open(encoding='utf8',newline='') as f:expected={r['date']:stamp(r['close_at']) for r in csv.DictReader(f)}
  for asset,rs in groups.items():
   actual={r['date']:r['instant'] for r in rs};lo=min(actual);hi=max(actual)
   for day,at in expected.items():
    if lo<=day<=hi and actual.get(day)!=at:raise ValueError('MISSING_SESSION_OR_WRONG_REAL_CLOSE_TIME:'+asset+':'+day)
 for e in readl(data/'events.jsonl'):
  rows=groups.get(e['asset'],[]);cutoff=stamp(e['information_cutoff'])
  candidates=[i for i,r in enumerate(rows) if r['instant']>=cutoff]
  if not candidates:out.append({'event_id':e['event_id'],'asset':e['asset'],'status':'NO_DECISION_PRICE'});continue
  i=candidates[0]
  if i<60:out.append({'event_id':e['event_id'],'asset':e['asset'],'status':'INSUFFICIENT_CAUSAL_WINDOW'});continue
  # No future row participates in features. A prediction at t is filled at t+1 close.
  hist=[r['close'] for r in rows[i-60:i+1]];rets=[hist[j]/hist[j-1]-1 for j in range(1,len(hist))]
  features=[hist[-1]/hist[-1-h]-1 for h in [1,5,20,60]]+[statistics.pstdev(rets[-20:]),statistics.pstdev(rets)]
  for h in [1,5,20]:
   end=i+h+1;fillable=i+1<len(rows);mature=end<len(rows)
   out.append({'event_id':e['event_id'],'asset':e['asset'],'decision_date':rows[i]['date'],'information_cutoff':e['information_cutoff'],
    'forecast_origin':rows[i]['close_at'],'first_fill_time':rows[i+1]['close_at'] if fillable else None,'horizon':h,
    'return_start':rows[i+1]['close_at'] if fillable else None,'return_end':rows[end]['close_at'] if mature else None,
    'target_formula':'close[t+h+1]/close[t+1]-1','target':rows[end]['close']/rows[i+1]['close']-1 if mature else None,
    'price_features':features,'status':'MATURE' if mature else 'RIGHT_CENSORED_NO_2024_READ',
    'price_license':'USER_SUPPLIED_AUTHORIZED_DATA_DO_NOT_REDISTRIBUTE_BY_DEFAULT'})
 return out

def solve(a,b):
 a=[list(row)+[v] for row,v in zip(a,b)];n=len(b)
 for j in range(n):
  k=max(range(j,n),key=lambda k:abs(a[k][j]));a[j],a[k]=a[k],a[j]
  if abs(a[j][j])<1e-15:raise ValueError('SINGULAR')
  d=a[j][j];a[j]=[v/d for v in a[j]]
  for k in range(n):
   if k==j:continue
   d=a[k][j];a[k]=[x-d*y for x,y in zip(a[k],a[j])]
 return [row[-1] for row in a]
def ridge(x,y,alpha=10):
 n=len(x);p=len(x[0]);mean=[statistics.mean(r[j] for r in x) for j in range(p)]
 sd=[max(1e-9,statistics.pstdev(r[j] for r in x)) for j in range(p)];ym=statistics.mean(y)
 z=[[(r[j]-mean[j])/sd[j] for j in range(p)] for r in x]
 mat=[[sum(r[j]*r[k] for r in z)+(alpha if j==k else 0) for k in range(p)] for j in range(p)]
 b=[sum(r[j]*(v-ym) for r,v in zip(z,y)) for j in range(p)];coef=solve(mat,b)
 return {'mean':mean,'sd':sd,'coef':coef,'intercept':ym,'alpha':alpha,'train_n':n}
def pred(m,x):return m['intercept']+sum(c*(v-a)/s for c,v,a,s in zip(m['coef'],x,m['mean'],m['sd']))

def benchmark(data,prices):
 aligned=align(data,prices);rules={s['event_id']:s for s in readl(data/'rule_economic_states.jsonl')}
 agents={s['event_id']:s for s in readl(data/'real_agent_economic_states.jsonl')} if (data/'real_agent_economic_states.jsonl').exists() else {}
 event_meta={e['event_id']:e for e in readl(data/'events.jsonl')};facts=readl(data/'evidence.jsonl')
 for eid,s in agents.items():s['validation']=audit_agent(s,event_meta[eid],facts)
 vectors={s['event_id']:s['vector'] for s in readl(data/'PUBLIC_QWEN_VECTORS.jsonl')} if (data/'PUBLIC_QWEN_VECTORS.jsonl').exists() else {}
 valid={e for e,s in agents.items() if s.get('validation',{}).get('source_legality') in {'PASS','FIELD_ISOLATION'} and any(c['status']=='PASS' for c in s.get('validation',{}).get('comparisons',[]))}
 if vectors:valid=valid & set(vectors)
 rows=[r for r in aligned if r.get('status')=='MATURE' and r['event_id'] in valid]
 mismatches={}
 for eid in valid:
  earlier=[j for j in valid if event_meta[j]['asset']!=event_meta[eid]['asset'] and event_meta[j]['information_cutoff']<event_meta[eid]['information_cutoff']]
  mismatches[eid]=max(earlier,key=lambda j:(event_meta[j]['information_cutoff'],j)) if earlier else None
 predictions=[];models=[];summaries=[]
 for h in [1,5,20]:
  rr=[r for r in rows if r['horizon']==h];train=[r for r in rr if r['decision_date'][:4]=='2021' and r['return_end'][:4]=='2021']
  cal=[r for r in rr if r['decision_date'][:4]=='2022' and r['return_end'][:4]=='2022'];test=[r for r in rr if r['decision_date'][:4]=='2023']
  if min(len(train),len(cal),len(test))<2:
   summaries.append({'horizon':h,'status':'INSUFFICIENT_MATCHED_EVENTS','train':len(train),'cal':len(cal),'eval':len(test)});continue
  def features(r,rep):
   eid=r['event_id']
   if rep=='R0_RULE':semantic=vector_rule(rules[eid])
   elif rep=='R2_AGENT_FACT_COMPARISONS':semantic=vector_agent(agents[eid])
   elif rep=='R1_QWEN_PUBLIC_FACTS':semantic=vectors[eid]
   elif rep=='R3_QWEN_AGENT':semantic=vectors[eid][:8]+vector_agent(agents[eid])[:8]
   elif rep=='MISMATCH_TIME_LEGAL_WRONG_COMPANY':semantic=vector_agent(agents[mismatches[eid]]) if mismatches[eid] else [0.]*16
   else:semantic=[0.]*16
   return r['price_features']+semantic
  representations=['PRICE','R0_RULE','R2_AGENT_FACT_COMPARISONS','EMPTY','MISMATCH_TIME_LEGAL_WRONG_COMPANY']
  if vectors:representations+=['R1_QWEN_PUBLIC_FACTS','R3_QWEN_AGENT']
  for rep in representations:
   # Every arm has identical 22-coordinate head; PRICE/EMPTY zero semantic.
   m=ridge([features(r,rep) for r in train],[r['target'] for r in train])
   # Same calibration rule for every arm, fitted only on mature 2022 labels.
   pc=[pred(m,features(r,rep)) for r in cal];den=sum(v*v for v in pc)
   shrink=max(0,min(1,sum(v*r['target'] for v,r in zip(pc,cal))/den)) if den else 0
   m.update({'representation':rep,'horizon':h,'shrink':shrink,'cal_n':len(cal)})
   models.append(m);pp=[]
   for r in test:
    raw=pred(m,features(r,rep));v=raw*shrink
    predictions.append({k:r[k] for k in ['event_id','asset','decision_date','horizon','target','return_end']}|{'representation':rep,'raw_prediction':raw,'prediction':v,'squared_error':(v-r['target'])**2,
     'mismatch_source_event':mismatches[r['event_id']] if rep=='MISMATCH_TIME_LEGAL_WRONG_COMPANY' else None});pp.append((v,r['target']))
   summaries.append({'representation':rep,'horizon':h,'train_events':len(train),'cal_events':len(cal),'eval_events':len(test),
    'mse':statistics.mean((p-y)**2 for p,y in pp),'mae':statistics.mean(abs(p-y) for p,y in pp),'shrink':shrink,'status':'EXPLORATORY_SMALL_MATCHED_FILINGS_SUBSET'})
  for rep in ['ZERO_RETURN','TRAINING_MEAN']:
   v=0 if rep=='ZERO_RETURN' else statistics.mean(r['target'] for r in train)
   summaries.append({'representation':rep,'horizon':h,'train_events':len(train),'cal_events':len(cal),'eval_events':len(test),
    'mse':statistics.mean((v-r['target'])**2 for r in test),'mae':statistics.mean(abs(v-r['target']) for r in test),'status':'EXPLORATORY_SMALL_MATCHED_FILINGS_SUBSET'})
 return {'aligned':aligned,'predictions':predictions,'models':models,'summary':summaries,
  'notes':{'R1_QWEN':'ACTUAL_FROZEN_NEW_PUBLIC_FACT_EMBEDDINGS' if vectors else 'NOT_RUN_NO_EXACT_MATCH_EMBEDDINGS',
    'R3':'ACTUAL_8_QWEN_PLUS_8_AGENT_FACT_SLOTS' if vectors else 'NOT_RUN_R1_UNAVAILABLE','risk_q10':'NOT_RUN_NO_NEW_RISK_MODEL','private_580_scores':'SEPARATE_POPULATION_NOT_MIXED',
    'mismatch':'Most recent earlier wrong-company state, same chronology; missing predecessor is explicit zero semantic control, not a claim of no effect',
    'mismatch_missing_predecessors':sum(v is None for v in mismatches.values()),
    'financial_increment':'NOT_ESTABLISHED','coverage':'All arms use exact same valid real-Agent filing event intersection'}}

def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['verify','reproduce','query','align','benchmark']);p.add_argument('--data',type=Path,default=Path(__file__).resolve().parent/'data');p.add_argument('--asset');p.add_argument('--prices',type=Path);p.add_argument('--output',type=Path,default=Path('reproduction'))
 a=p.parse_args();data=a.data
 if a.command in ['verify','reproduce']:
  v=verify(data);a.output.mkdir(parents=True,exist_ok=True);writej(a.output/'VERIFICATION.json',v);print(json.dumps(v));return
 if a.command=='query':
  print(json.dumps({'events':[e for e in readl(data/'events.jsonl') if e['asset']==a.asset],
   'states':[s for s in readl(data/'rule_economic_states.jsonl') if s['asset']==a.asset]},ensure_ascii=False));return
 if not a.prices:p.error('--prices requires an authorized CSV with asset,date,close,close_at')
 a.output.mkdir(parents=True,exist_ok=True)
 if a.command=='align':writel(a.output/'price_alignment.jsonl',align(data,a.prices))
 else:
  b=benchmark(data,a.prices);writel(a.output/'price_alignment.jsonl',b.pop('aligned'));writel(a.output/'predictions.jsonl',b.pop('predictions'));writej(a.output/'BENCHMARK.json',b)
if __name__=='__main__':main()
